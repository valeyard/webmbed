
$(document).ready(function() {
  chrome.storage.sync.get(["webm"],function (obj){
    g = obj;
    if (g.webm){
      var pomf = new RegExp("[:A-Za-z0-9\.\/]+\.webm");
    
      $("a").each(function(index, image){
        $this = $(image)
        var text = $this.attr("href");
        var ur85 = pomf.exec(text);
        if (pomf.test(text)){
          var sth = '<video autoplay loop width="500" muted="true" controls> <source src="'+ur85[0]+'" type="video/webm"> </video>'
          $this.replaceWith(sth)
        }
      });
    }
  });
});


